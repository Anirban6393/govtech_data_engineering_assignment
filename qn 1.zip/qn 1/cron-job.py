!pip install python-crontab

from crontab import CronTab
import processing 

cron = CronTab(user='anirban')

job = cron.new(command='python processing.py')
job.dow.on('11:00')
cron.write()