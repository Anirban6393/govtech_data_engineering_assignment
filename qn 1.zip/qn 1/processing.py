import numpy as np
import pandas as pd

def process_data(dataframe):
    dataframe = dataframe.dropna(subset=['name'], axis=0)
    dataframe['first_name'] = dataframe['name'].str.split().str[0]
    dataframe['last_name'] = dataframe['name'].str.split().str[1]
    dataframe['above_100'] = dataframe['price'].apply(lambda x: True if x>100 else False)
    dataframe.price = dataframe.price.astype('str').str.strip("0").astype('float64')
    return dataframe.head(10)